from sklearn.datasets import fetch_20newsgroups
from sklearn.feature_extraction.text  import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
def baiyes():
    #1、获取数据
    news=fetch_20newsgroups(subset='a11')
    #2、划分数据集
    x_train, x_test, y_train, y_test=train_test_split(news.data,news.target,test_size=0.3)
    #3、特征工程
    tf = TfidfVectorizer()
    x_train = tf.fit_transform(x_train)
    x_test = tf.transform(x_test)
    print(tf.get_feature_names())
    x_test=tf.transform(x_test)
    #4、baiyes预估器流程
    mlb=MultinomialNB(alpha=1.0)
    mlb.fit(x_train,y_train)

    #5、模型评估
    y_predict = mlb.predict(x_test)
    print('y_predict:\n', y_predict)
    print('直接比对真实值和预测值:\n', y_test == y_predict)
    return None
if __name__ == '__main__':
    baiyes()
